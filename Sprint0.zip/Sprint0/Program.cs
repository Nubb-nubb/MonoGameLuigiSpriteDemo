﻿
using var game = new Sprint0.Game1();
game.Run();
